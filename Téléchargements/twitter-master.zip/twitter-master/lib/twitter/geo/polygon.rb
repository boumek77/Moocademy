require 'twitter/geo'

module Twitter
  class Geo
    class Polygon < Twitter::Geo
    end
  end
end
