class Timer
  #write your code here
end
